import React from 'react'

export const Profile = () => {
    return (
        <div>
            My Profile is Dope
        </div>
    )
}

export default Profile
