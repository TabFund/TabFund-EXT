import React from 'react'
import AddGift from './AddGift';
import AllGifts from './AllGifts';
import Stats from './Stats';
import Settings from './Settings';


export const Backoffice = (props) => {
    return (
        <div>
            Backoffice
        </div>
    )
}

export default Backoffice;
